# Cat Sandbox 3D · Hyper Edition: Android APK project

Your game is already inside: `app/src/main/assets/index.html`.
To update the game later, replace that file with your new HTML (keep the name `index.html`) and build again.

## Option A: build it in the cloud with GitHub (no PC software needed)
1. Make a free GitHub account and create a new repository.
2. Upload ALL the files from this folder, including the hidden `.github` folder.
   (On the GitHub website: "Add file" → "Upload files" and drag in the folder contents.)
   Tip: some computers hide the `.github` folder and it won't upload. If the Actions tab is empty, choose
   "Add file" → "Create new file", name it `.github/workflows/build-apk.yml`, and paste in the contents of that file from this folder.
3. Open the **Actions** tab. The "Build APK" job runs automatically and takes about 3–5 minutes.
4. Open the finished run and download **CatSandbox3D-apk** under "Artifacts". It's a .zip with the .apk inside.
5. Copy the .apk to your phone, open it, and allow "Install unknown apps" when asked.

## Option B: build it on a computer with Android Studio
1. Install Android Studio (free): https://developer.android.com/studio
2. Choose File → Open and pick this folder. Wait for "Gradle sync" to finish.
3. Choose Build → Build App Bundle(s) / APK(s) → Build APK(s).
4. Click "locate". The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## What the app does
- Fullscreen, landscape, no browser bars
- Progress, cats and songs are saved on the phone
- Music and sound effects work
- Vibration works on supported phones
- Android back button: pauses the game, then returns to the menu, then exits
